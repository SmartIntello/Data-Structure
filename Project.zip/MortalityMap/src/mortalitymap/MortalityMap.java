package mortalitymap;

import java.awt.AlphaComposite;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import javax.swing.*;
import javax.imageio.*;
import java.util.*;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.ss.usermodel.WorkbookFactory;

class MortalityMap {

    public static void main(String[] args) throws IOException, BiffException {
        String test = "";
        int year;
        System.out.println("Please enter the year you'd like to display.");
        Scanner kb = new Scanner(System.in);
        year = kb.nextInt();
        //can be improved by making an Array of Strings holding the name of all countries and asking the user for the location of the folder holding the images, and making a loop with that info to create all object and another individual loop to add the objects to the linked list.
        //Declaration of all Country objects
        try{
        Country Afghanistan = new Country("Afghanistan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Afghanistan.png")));
        Country Albania = new Country("Albania",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Albania.png")));
        Country Algeria = new Country("Algeria",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Algeria.png")));
        Country Angola = new Country("Angola",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Angola.png")));
        Country Argentina = new Country("Argentina",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Argentina.png")));
        Country Armenia = new Country("Armenia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Armenia.png")));
        Country Australia = new Country("Australia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Australia.png")));
        Country Austria = new Country("Austria",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Austria.png")));
        Country Azerbaijan = new Country("Azerbaijan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Australia.png")));
        Country Bangladesh = new Country("Bangladesh",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Bangladesh.png")));
        Country Belarus = new Country("Belarus",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Belarus.png")));
        Country Belize = new Country("Belize",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Belize.png")));
        Country Benin = new Country("Benin",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Benin.png")));
        Country Bhutan = new Country("Australia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Australia.png")));
        Country Bolivia = new Country("Bolivia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Bolivia.png")));
        Country Bosnia = new Country("Bosnia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Bosnia.png")));
        Country Botswana = new Country("Botswana",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Botswana.png")));
        Country Brazil = new Country("Brazil",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Brazil.png")));
        Country Bulgaria = new Country("Bulgaria",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Bulgaria.png")));
        Country Burkina = new Country("Burkina",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Burkina.png")));
        Country Burundi = new Country("Burundi",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Burundi.png")));
        Country Cambodia = new Country("Cambodia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Cambodia.png")));
        Country Cameroon = new Country("Cameroon",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Cameroon.png")));
        Country Canada = new Country("Canada",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Canada.png")));
        Country Caribean = new Country("Caribean",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Caribean.png")));
        Country Central_African_Republic = new Country("Central African Republic",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Central African Republic'.png")));
        Country Chad = new Country("Chad",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Chad.png")));
        Country Chile = new Country("Chile",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Chile.png")));
        Country China = new Country("China",ImageIO.read(new File("/Users/elyon/Desktop/Countries/China.png")));
        Country Colombia = new Country("Colombia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Colombia.png")));
        Country Congo = new Country("Congo",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Congo.png")));
        Country Costa_Rica = new Country("Costa Rica",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Costa Rica.png")));
        Country Cote_d_Ivoire = new Country("Cote d'Ivoire",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Cote d'Ivoire.png")));
        Country Croatia = new Country("Croatia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Croatia.png")));
        Country Czech_Republic = new Country("Czech Republic",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Czech Republic.png")));
        Country Djibouti = new Country("Djibouti",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Djibouti.png")));
        Country Denmark = new Country("Denmark",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Denmark.png")));
        Country Ecuador = new Country("Ecuador",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Ecuador.png")));
        Country Egypt = new Country("Egypt",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Egypt.png")));
        Country El_Salvador = new Country("El Salvador",ImageIO.read(new File("/Users/elyon/Desktop/Countries/El Salvador.png")));
        Country Eritrea = new Country("Eritrea",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Eritrea.png")));
        Country Estonia = new Country("Estonia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Estonia.png")));
        Country eSwatini = new Country("eSwatini",ImageIO.read(new File("/Users/elyon/Desktop/Countries/eSwatini.png")));
        Country Ethopia = new Country("Ethopia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Ethopia.png")));
        Country Finland = new Country("Finland",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Finland.png")));
        Country France = new Country("France",ImageIO.read(new File("/Users/elyon/Desktop/Countries/France.png")));
        Country French_Guiana = new Country("French Guiana",ImageIO.read(new File("/Users/elyon/Desktop/Countries/French Guiana.png")));
        Country Gabon = new Country("Gabon",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Gabon.png")));
        Country Georgia = new Country("Georgia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Georgia.png")));
        Country Germany = new Country("Germany",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Germany.png")));
        Country Ghana = new Country("Ghana",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Ghana.png")));
        Country Greece = new Country("Greece",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Greece.png")));
        Country Greenland = new Country("Greenland",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Greenland.png")));
        Country Guatemala = new Country("Guatemala",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Guatemala.png")));
        Country Guinea = new Country("Guinea",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Guinea.png")));
        Country Guyana = new Country("Guyana",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Guyana.png")));
        Country Honduras = new Country("Honduras",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Honduras.png")));
        Country Iceland = new Country("Iceland",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Iceland.png")));
        Country India = new Country("India",ImageIO.read(new File("/Users/elyon/Desktop/Countries/India.png")));
        Country Indonesia = new Country("Indonesia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Indonesia.png")));
        Country Iran = new Country("Iran",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Iran.png")));
        Country Iraq = new Country("Iraq",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Iraq.png")));
        Country Ireland = new Country("Ireland",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Ireland.png")));
        Country Italy = new Country("Italy",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Italy.png")));
        Country Japan = new Country("Japan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Japan.png")));
        Country Jordan = new Country("Jordan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Jordan.png")));
        Country Kazakhstan = new Country("Kazakhstan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Kazakhstan.png")));
        Country Kenya = new Country("Kenya",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Kenya.png")));
        Country Kuwait = new Country("Kuwait",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Kuwait.png")));
        Country Kyrgyztan = new Country("Kyrgyztan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Kyrgyztan.png")));
        Country Laos = new Country("Laos",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Laos.png")));
        Country Latvia = new Country("Latvia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Latvia.png")));
        Country Lesotho = new Country("Lesotho",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Lesotho.png")));
        Country Liberia = new Country("Liberia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Liberia.png")));
        Country Libya = new Country("Libya",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Libya.png")));
        Country Lithuania = new Country("Lithuania",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Lithuania.png")));
        Country Macedonia = new Country("Macedonia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Macedonia.png")));
        Country Madagascar = new Country("Madagascar",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Madagascar.png")));
        Country Malawi = new Country("Malawi",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Malawi.png")));
        Country Malaysia = new Country("Malaysia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Malaysia.png")));
        Country Mali = new Country("Mali",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Mali.png")));
        Country Mauritania = new Country("Mauritania",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Mauritania.png")));
        Country Mexico = new Country("Mexico",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Mexico.png")));
        Country Mongolia = new Country("Mongolia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Mongolia.png")));
        Country Morocco = new Country("Morocco",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Morocco.png")));
        Country Mozambique = new Country("Mozambique",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Mozambique.png")));
        Country Myanmar = new Country("Myanmar",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Myanmar.png")));
        Country Namibia = new Country("Namibia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Namibia.png")));
        Country Nepal = new Country("Nepal",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Nepal.png")));
        Country Netherlands = new Country("Netherlands",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Netherlands.png")));
        Country New_Zealand = new Country("New Zealand",ImageIO.read(new File("/Users/elyon/Desktop/Countries/New Zealand.png")));
        Country Nicaragua = new Country("Nicaragua",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Nicaragua.png")));
        Country Niger = new Country("Niger",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Niger.png")));
        Country Nigeria = new Country("Nigeria",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Nigeria.png")));
        Country Norway = new Country("Norway",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Norway.png")));
        Country Oman = new Country("Oman",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Oman.png")));
        Country Pakistan = new Country("Pakistan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Pakistan.png")));
        Country Panama = new Country("Panama",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Panama.png")));
        Country Papua_New_Guinea = new Country("Papua New Guinea",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Papua New Guinea.png")));
        Country Paraguay = new Country("Paraguay",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Paraguay.png")));
        Country Peru = new Country("Peru",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Peru.png")));
        Country Philippines = new Country("Philippines",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Philippines.png")));
        Country Poland = new Country("Poland",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Poland.png")));
        Country Portugal = new Country("Portugal",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Portugal.png")));
        Country Qatar = new Country("Qatar",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Qatar.png")));
        Country Republic_of_the_Congo = new Country("Republic of the Congo",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Republic of the Congo.png")));
        Country Romania = new Country("Romania",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Romania.png")));
        Country Russia = new Country("Russia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Russia.png")));
        Country Rwanda = new Country("Rwanda",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Rwanda.png")));
        Country Saudi_Arabia = new Country("Saudi Arabia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Saudi Arabia.png")));
        Country Senegal = new Country("Senegal",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Senegal.png")));
        Country Serbia = new Country("Serbia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Serbia.png")));
        Country Sierra_Leone = new Country("Sierra Leone",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Sierra Leone.png")));
        Country Slovakia = new Country("Slovakia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Slovakia.png")));
        Country Slovenia = new Country("Slovenia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Slovenia.png")));
        Country Sommalia = new Country("Sommalia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Sommalia.png")));
        Country South_Africa = new Country("South Africa",ImageIO.read(new File("/Users/elyon/Desktop/Countries/South Africa.png")));
        Country South_Korea = new Country("South Korea",ImageIO.read(new File("/Users/elyon/Desktop/Countries/South Korea.png")));
        Country Spain = new Country("Spain",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Spain.png")));
        Country Sudan = new Country("Sudan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Sudan.png")));
        Country Suriname = new Country("Suriname",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Suriname.png")));
        Country Sri_Lanka = new Country("Sri Lanka",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Sri Lanka.png")));
        Country Sweden = new Country("Sweden",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Sweden.png")));
        Country Switzerland = new Country("Switzerland",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Switzerland.png")));
        Country Syria = new Country("Syria",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Syria.png")));
        Country Taiwan = new Country("Taiwan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Taiwan.png")));
        Country Tajikistan = new Country("Tajikistan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Tajikistan.png")));
        Country Tanzania = new Country("Tanzania",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Tanzania.png")));
        Country Thailand = new Country("Thailand",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Thailand.png")));
        Country Togo = new Country("Togo",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Togo.png")));
        Country Tunisa = new Country("Tunisa",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Tunisa.png")));
        Country Turkey = new Country("Turkey",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Turkey.png")));
        Country Turkmenistan = new Country("Turkmenistan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Turkmenistan.png")));
        Country Uganda = new Country("Uganda",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Uganda.png")));
        Country Ukraine = new Country("Ukraine",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Ukraine.png")));        
        Country United_Kingdom = new Country("United Kingdom",ImageIO.read(new File("/Users/elyon/Desktop/Countries/United Kingdom.png")));
        Country United_States = new Country("United_States",ImageIO.read(new File("/Users/elyon/Desktop/Countries/United_States.png")));  
        Country Uruguay = new Country("Uruguay",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Uruguay.png")));
        Country Uzbekistan = new Country("Uzbekistan",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Uzbekistan.png")));  
        Country Venezuela = new Country("Venezuela",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Venezuela.png")));
        Country Vietnam = new Country("Vietnam",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Vietnam.png")));
        Country Western_Sahara = new Country("Western Sahara",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Western Sahara.png")));  
        Country Yemen = new Country("Yemen",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Yemen.png")));
        Country Zambia = new Country("Zambia",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Zambia.png")));  
        Country Zimbabwe = new Country("Zimbabwe",ImageIO.read(new File("/Users/elyon/Desktop/Countries/Zimbabwe.png")));        
        
        //Adding every Country object to the LinkedList
        LinkedList<Country> Countries = new LinkedList<Country>();
        Countries.add(Afghanistan);
        Countries.add(Albania);
        Countries.add(Algeria);
        Countries.add(Angola);
        Countries.add(Argentina);
        Countries.add(Armenia);
        Countries.add(Australia);
        Countries.add(Austria);
        Countries.add(Azerbaijan);
        Countries.add(Bangladesh);
        Countries.add(Belarus);
        Countries.add(Belize);
        Countries.add(Benin);
        Countries.add(Bhutan);
        Countries.add(Bolivia);
        Countries.add(Bosnia);
        Countries.add(Botswana);
        Countries.add(Brazil);
        Countries.add(Bulgaria);
        Countries.add(Burkina);
        Countries.add(Burundi);
        Countries.add(Cambodia);
        Countries.add(Cameroon);
        Countries.add(Canada);
        Countries.add(Caribean);
        Countries.add(Central_African_Republic);
        Countries.add(Chad);
        Countries.add(Chile);
        Countries.add(China);
        Countries.add(Colombia);
        Countries.add(Congo);
        Countries.add(Costa_Rica);
        Countries.add(Cote_d_Ivoire);
        Countries.add(Croatia);
        Countries.add(Czech_Republic);
        Countries.add(Denmark);
        Countries.add(Djibouti);
        Countries.add(Ecuador);
        Countries.add(Egypt);
        Countries.add(El_Salvador);
        Countries.add(Eritrea);
        Countries.add(Estonia);
        Countries.add(eSwatini);
        Countries.add(Ethopia);
        Countries.add(Finland);
        Countries.add(France);
        Countries.add(French_Guiana);
        Countries.add(Gabon);
        Countries.add(Georgia);
        Countries.add(Germany);
        Countries.add(Ghana);
        Countries.add(Greece);
        Countries.add(Greenland);
        Countries.add(Guatemala);
        Countries.add(Guinea);
        Countries.add(Guyana);
        Countries.add(Honduras);
        Countries.add(Iceland);
        Countries.add(India);
        Countries.add(Indonesia);
        Countries.add(Iran);
        Countries.add(Iraq);
        Countries.add(Ireland);
        Countries.add(Italy);
        Countries.add(Japan);
        Countries.add(Jordan);
        Countries.add(Kazakhstan);
        Countries.add(Kenya);
        Countries.add(Kuwait);
        Countries.add(Kyrgyztan);
        Countries.add(Laos);
        Countries.add(Latvia);
        Countries.add(Lesotho);
        Countries.add(Liberia);
        Countries.add(Libya);
        Countries.add(Lithuania);
        Countries.add(Macedonia);
        Countries.add(Madagascar);
        Countries.add(Malawi);
        Countries.add(Malaysia);
        Countries.add(Mali);
        Countries.add(Mauritania);
        Countries.add(Mexico);
        Countries.add(Mongolia);
        Countries.add(Morocco);
        Countries.add(Mozambique);
        Countries.add(Myanmar);
        Countries.add(Namibia);
        Countries.add(Nepal);
        Countries.add(Netherlands);
        Countries.add(New_Zealand);
        Countries.add(Nicaragua);
        Countries.add(Niger);
        Countries.add(Nigeria);
        Countries.add(Norway);
        Countries.add(Oman);
        Countries.add(Pakistan);
        Countries.add(Panama);
        Countries.add(Papua_New_Guinea);
        Countries.add(Paraguay);
        Countries.add(Peru);
        Countries.add(Philippines);
        Countries.add(Poland);
        Countries.add(Portugal);
        Countries.add(Qatar);
        Countries.add(Republic_of_the_Congo);
        Countries.add(Romania);
        Countries.add(Russia);
        Countries.add(Rwanda);
        Countries.add(Saudi_Arabia);
        Countries.add(Senegal);
        Countries.add(Serbia);
        Countries.add(Sierra_Leone);
        Countries.add(Slovakia);
        Countries.add(Slovenia);
        Countries.add(Sommalia);
        Countries.add(South_Africa);
        Countries.add(South_Korea);
        Countries.add(Spain);
        Countries.add(Sudan);
        Countries.add(Suriname);
        Countries.add(Sri_Lanka);
        Countries.add(Sweden);
        Countries.add(Switzerland);
        Countries.add(Syria);
        Countries.add(Taiwan);
        Countries.add(Tajikistan);
        Countries.add(Tanzania);
        Countries.add(Thailand);
        Countries.add(Togo);
        Countries.add(Tunisa);
        Countries.add(Turkey);
        Countries.add(Turkmenistan);
        Countries.add(Uganda);
        Countries.add(Ukraine);
        Countries.add(United_Kingdom);
        Countries.add(United_States);
        Countries.add(Uruguay);
        Countries.add(Uzbekistan);
        Countries.add(Venezuela);
        Countries.add(Vietnam);
        Countries.add(Western_Sahara);
        Countries.add(Yemen);
        Countries.add(Zambia);
        Countries.add(Zimbabwe);
        
        BufferedImage background = ImageIO.read(new File("/Users/elyon/Desktop/Countries/World_bg.png"));
        Graphics2D g = (Graphics2D) background.getGraphics();
        double maxrate=0,minrate=100;
        for(int i=0;i<Countries.size();i++){
            Countries.get(i).setMortalityRate(getMortalityRate(Countries.get(i),year));
            if(maxrate<Countries.get(i).getMortalityRate()){maxrate = Countries.get(i).getMortalityRate();}
            if(minrate>Countries.get(i).getMortalityRate()){minrate = Countries.get(i).getMortalityRate();}
        }
        for(int i=0;i<Countries.size();i++){
            int  newrange,newmax = 255, newmin = 30, newvalue;
            double oldrange = (maxrate - minrate);
        if(oldrange==0)
        {
            newvalue = newmin;
        }
        else
        {
         newrange = (newmax-newmin);
         newvalue = (int) ((((Countries.get(i).getMortalityRate() - minrate)*newrange)/oldrange)+ newmin);
        }
        int colors=102;
            Countries.get(i).setColor(new Color(newvalue,colors,0));
            Countries.get(i).setCountry_IMG(dye(Countries.get(i).getIMG(),Countries.get(i).getColor()));
            g.drawImage(Countries.get(i).getIMG(), 0, 0, null);
        }
        File outputfile = new File("/Users/elyon/Desktop/Countries/test.png");
        ImageIO.write(background, "png", outputfile);
        System.out.println("Maximum Rate: "+maxrate);
        System.out.println("Minimum Rate: "+minrate);
        
        }catch(IOException e){e.printStackTrace();}

    }//end of Main
  public static double getMortalityRate(Country country, int year) throws BiffException, IOException{
       File input = new File("C:\\Users\\elyon\\Desktop\\Countries\\Data.xls");
       Workbook wb;
       double value=0;
       boolean flag = false;
       String name = country.getName();
       try{
            wb = Workbook.getWorkbook(input);
            Sheet sheet = wb.getSheet(0);
            int col = sheet.getColumns(), j=1;
            int row = sheet.getRows(),i=1;
            for(;i<row ;i++)
            {
            Cell c = sheet.getCell(j,i);
            Cell a = sheet.getCell(0, i);
            if(name.equals(a.getContents()))
            {
                for(;j<col;j++)
                {
                    if(year==Integer.valueOf(c.getContents()))
                    {
                        Cell d = sheet.getCell(2,i);
                        float rate = Float.parseFloat(d.getContents());
                        flag=true;
                        return(rate);
                        
                    }
                }
                 j=1;
            }
            if(flag==false){
                for(;i<row ;i++)
            {
             c = sheet.getCell(j,i);
             a = sheet.getCell(0, i);
            if(name.equals(a.getContents()))
            {
                for(;j<col;j++)
                {
                    if(1990==Integer.valueOf(c.getContents()))
                    {
                        Cell d = sheet.getCell(2,i);
                        float rate = Float.parseFloat(d.getContents());
                        value = (-0.114*year + 238.81);
                
                return((value+rate)/4);
                    }
                }
            }
        }}}
    }catch(NumberFormatException E){System.out.println("error: "+E);
  }
       return(value);
}
  
        private static BufferedImage dye(BufferedImage image, Color color)
    {
        int w = image.getWidth();
        int h = image.getHeight();
        BufferedImage dyed = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = dyed.createGraphics();
        g.drawImage(image, 0,0, null);
        g.setComposite(AlphaComposite.SrcAtop);
        g.setColor(color);
        g.fillRect(0,0,w,h);
        g.dispose();
        return dyed;
    }
}
