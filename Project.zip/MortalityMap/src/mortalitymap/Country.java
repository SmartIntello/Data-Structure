package mortalitymap;

import java.awt.image.BufferedImage;
import java.awt.*;

public class Country {
 private String Name;
 private BufferedImage Country_IMG;
 private Color color;
 private float mortality;
    public Country(String name,BufferedImage IMG)
    {
        Name = name;
        Country_IMG = IMG;
    }
    public String getName(){
        return(Name);
    }
    public BufferedImage getIMG(){
        return(Country_IMG);
    }
    public void setMortalityRate(double rate){
         mortality = (int)rate;
         color = new Color(102, 0, 102);
                 //new Color(255,mortality*20,0);
    }
    public void setColor(Color color){
        this.color = color;
    }
    public Color getColor(){
        return(color);
    }
    public double getMortalityRate(){
        return(mortality);
    }
    public void setCountry_IMG(BufferedImage imgg){
        Country_IMG = imgg;
    }
}